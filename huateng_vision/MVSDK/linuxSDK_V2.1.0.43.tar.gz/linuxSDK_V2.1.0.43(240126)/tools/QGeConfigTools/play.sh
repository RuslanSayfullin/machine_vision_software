cd /home/mind/cameraIP/
cp /home/mind/build-QGeConfigTools-Desktop_Qt_5_9_0_GCC_64bit-Release/QGeConfigTools /home/mind/cameraIP/QGeConfigTools
linuxdeployqt /home/mind/cameraIP/QGeConfigTools -appimage

